import bpy

class ROS_PT_info(bpy.types.Panel):
    bl_idname = "ROS_PT_info"
    bl_label = "Info"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "ROS Person"

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.label(text="For using Person message type you need to import an MHX2 avatar")
        col.label(text="Plugin created by Andrea Tessarolo.")
        col.label(text="v1.0")
        row = col.row()

